# Shopping Cart Web Application

A simple Java-based shopping cart web application using JSP and Servlets.

## Features

- User authentication (login/logout)
- Add products to cart
- Update cart quantities
- Place orders
- Product listing with images
- Modular DAO and Servlet structure

## Tech Stack

- Java 8+
- JSP
- Servlets
- Maven
- MySQL
- Apache Tomcat

## Setup Instructions

1. Configure your MySQL database (see `src/main/resources/db.properties`)
2. Import this project into Eclipse or IntelliJ as a Maven project
3. Build with:
    mvn clean package
4. Deploy the generated WAR to Tomcat's `webapps` folder
5. Access via:
    http://localhost:8080/shopping-cart

## Credentials

Database user: `root`  
Database password: `root`  

## License

MIT License