package userDoa;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class OrderDao {
	private Connection con;
	private String query;
	private PreparedStatement ps;
	private ResultSet rs;
	
}
