package db.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;

public class DBconnection {
    private static Connection conn = null;
    static {
        try {
            Properties props = new Properties();
            InputStream in = DBconnection.class.getClassLoader().getResourceAsStream("db.properties");
            props.load(in);
            String url = props.getProperty("db.url");
            String user = props.getProperty("db.username");
            String password = props.getProperty("db.password");
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConn() throws SQLException {
        return conn;
    }
}